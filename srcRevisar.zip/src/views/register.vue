<template>
  <div class="FormRegister">
    <div class="register">
      <div class="title">
        <h1 class="text-center">Sign Up</h1>
      </div>
      <form class="formulario" action="#" @submit.prevent="register">
        <div class="form-group">
          <input
            type="text"
            class="form-control formulario__input"
            aria-describedby="emailHelp"
            v-model="Fullname"
            @click="forms"
          />
          <label for="exampleInputEmail1" class="formulario__label">
            <font-awesome-icon icon="user" />Fullname
          </label>
        </div>

        <div class="form-group">
          <input
            type="email"
            class="form-control formulario__input"
            aria-describedby="emailHelp"
            v-model="email"
            @click="forms"
          />
          <label for="exampleInputEmail1" class="formulario__label">
            <font-awesome-icon icon="user" />Email
          </label>
        </div>

        <div class="form-group">
          <input
            type="password"
            class="form-control formulario__input"
            v-model="password"
            @click="forms"
          />
          <label for="exampleInputPassword1" class="formulario__label">
            <font-awesome-icon icon="key" />Password
          </label>
        </div>

        <button type="submit" class="btn btn-lg btn-block btn-success button">SignUp</button>
      </form>
    </div>
    <MenuBottom />
  </div>
</template>
<script>
import MenuBottom from "@/components/MenuBottom.vue";

import firebase from "firebase";
import router from "../router";
export default {
  name: "register",
  components: {
    MenuBottom
  },

  data() {
    return {
      log: { nickname: "" },
      Fullname: "",
      email: "",
      password: "",
      trigger: "",
      error: ""
    };
  },
  methods: {
    register() {
      this.trigger = "";
      if (this.Fullname && this.email && this.password) {
        firebase
          .auth()
          .createUserWithEmailAndPassword(this.email, this.password)
          .then(user => {
            this.Fullname = "";
            this.email = "";
            this.password = "";
            alert("Registrado con exito")
            this.$router.push({ name: "login" });
          })
          .catch(err => {
            this.error = err.message;
          });
      } else {
        this.trigger = "Todos los campos son requeridos";
      }
      // evt.preventDefault()
    },
    forms() {
      var input = document.getElementsByClassName("formulario__input");
      for (var i = 0; i < input.length; i++) {
        input[i].addEventListener("keyup", function() {
          if (this.value.length >= 1) {
            this.nextElementSibling.classList.add("fijar");
          } else {
            this.nextElementSibling.classList.remove("fijar");
          }
        });
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.button{
  color:white;
background: rgba(25,125,10,1);
background: -moz-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: -webkit-gradient(left top, left bottom, color-stop(0%, rgba(25,125,10,1)), color-stop(51%, rgba(73,158,58,1)), color-stop(60%, rgba(67,168,57,1)), color-stop(71%, rgba(61,184,65,1)), color-stop(100%, rgba(96,201,91,1)));
background: -webkit-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: -o-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: -ms-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: linear-gradient(to bottom, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#197d0a', endColorstr='#60c95b', GradientType=0 );

}
@import "@/scss/coolors.scss";
.FormRegister {
  background-image: url("../assets/backlogin2.jpg");
height: 100vh;
  border: 2px solid $sombra;
  border-radius: 20px;
  background-color: $blanco;
  display: flex;
  flex-direction: column;
  justify-content: center;

  .title { 
    h1 {
      color:white;
      margin-bottom: 1vh;
    }
  }
  .formulario {
    padding: 6%;
    .formulario__label {
      color: $sombra;
      font-size: 20px;
      margin-top: -80px;
      z-index: 2;
      padding-left: 15px;
      position: absolute;
      transition: 0.2s;
    }
    .formulario__input {
      font-size: 20px;
      padding: 20px;
      margin-bottom: 40px;
    }
    .formulario__input:focus + .formulario__label {
      margin-top: -120px;
      color: black;
    }
    .formulario__button:hover {
      background-color: $formBtn;
      transition: all 500ms ease;
    }
    .fijar {
      margin-top: -120px;
      color: $negro;
    }
  }
}
</style>