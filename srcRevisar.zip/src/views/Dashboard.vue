<template>
  <div class="dashboard">
    <headerPage />
    <carousel />
    <matchesLive />
    <MenuBottom />
  </div>
</template>
<script>
import headerPage from "@/components/headerPage.vue"
import MenuBottom from "@/components/MenuBottom.vue"
import carousel from '@/components/carousel.vue'
import matchesLive from '@/components/matchLive.vue'
import firebase from 'firebase';

export default {
  name: "home",
  components: {
    headerPage,
    MenuBottom,
    carousel,
    matchesLive
  },
  data(){
    return{
      user:null
    }
  },
  created() {
    firebase.auth().onAuthStateChanged(user => {
      if (user) {
        this.user = user;
      } else {
        this.user = null;
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.dashboard{
  background-image: url("../assets/paste.jpg");
}
</style>