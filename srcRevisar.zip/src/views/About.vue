<template>
  <div>
      <headerPage />
      <infogame />
    <MenuBottom />
  </div>
</template>
<script>
import headerPage from '@/components/headerPage.vue'
import MenuBottom from '@/components/MenuBottom.vue'
import infogame from '@/components/infoGame.vue'
export default {
    name:'about',
  components: {
    headerPage,
    infogame,
    MenuBottom
  }
}
</script>
<style lang="scss" scoped>
  
</style>