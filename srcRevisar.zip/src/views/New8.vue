<template>
  <div class="new8">
    <img alt="gatos" src="../assets/microbio.jpg" width="200">
    <main class="container">
      <h2>Marcha atrás a la clausura parcial del Gigante</h2>
        <h4>El Ministerio de Seguridad de Santa Fe sancionó a Rosario Central por el uso de pirotecnia en el partido contra Gimnasia, pero este viernes decidió levantar la suspensión: “No se van a penalizar las tribunas”.</h4>
          <p>Luego de los los incidentes en la victoria 1-0 contra Gimnasia por la fecha 20 de la Superliga, el Ministerio de Seguridad de Santa Fe decidió sancionar a Rosario Central con una clausura parcial del Gigante de Arroyito, pero este viernes por la mañana dio marcha atrás y dejó sin efecto la sanción. De esta manera, el Canalla tendrá todo su estadio habilitado para jugar el domingo ante Arsenal.</p>
          <p>El miércoles, el Ministerio de Seguridad de Santa Fe decidió sancionar al Canalla y, a partir de un comunicado, sostuvo que “se realizará la clausura preventiva en las secciones del estadio que protagonizaron el uso ilegal de pirotecnia" para el partido contra Arsenal el 1° de marzo. De esta manera, clausuraron "la tribuna norte (que es la que da al club de Regatas, donde se ubica su hinchada) en su totalidad, alta y baja, y la platea Este (las gradas de plateas bajas y la bandeja de plateas altas)".</p>
          <p>Las medidas de prevención fueron informadas al club durante una primera reunión de coordinación que tuvo lugar en la sede de Gobierno provincial de Rosario y a la que asistieron representantes del club, policía y Ministerio de Seguridad.</p> 
          <p>Sin embargo, en las últimas horas hubo un giro inesperado. Germán Montenegro, secretario de Seguridad de la provincia de Santa fe, aseguró que finalmente el choque ante el equipo de Sarandí se jugará con total normalidad luego de una nueva reunión en la que participó el gobernador Omar Perotti. "No se van a penalizar las tribunas, la sanción se cambia por más control de seguridad. Se tomó la decisión de ser muy fuertes en el tema seguridad", expresó.</p>
          <p>La clausura preventiva se realizará en las secciones del estadio que protagonizaron el uso ilegal de pirotecnia y desde donde fueron arrojadas seis bombas de estruendo de 2,5 pulgadas al terreno de juego en el partido con Gimnasia y Esgrima de La Plata el 15 de febrero.</p>         
          <p>La disposición ministerial ordena la elevación de las actuaciones policiales al Ministerio Público de la Acusación para que se investigue si el ataque con explosivos pudiera configurar el delito de amenazas (Art. 149 bis del código penal).</p>
          <p>Además, el texto anticipa que se solicitará al Ministerio de Seguridad de la Nación que convoque a la AFA a una reunión para actualizar el perfil de riesgo de la provincia de Santa Fe, a fin de optimizar los criterios de sanciones y penalidades emitidas por el Tribunal de Disciplina de la entidad.</p>
          <p>Finalmente, en el mismo instrumento el Ministerio solicita una reunión de trabajo con “la Agencia Nacional de Materiales Controlados (ANMAC) para contribuir a la identificación de circuitos de fabricación y comercialización de pirotecnia ilegal” en la provincia".</p>
    </main>
  </div>    
</template>
