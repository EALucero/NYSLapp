<template>
  <div class="FormLogin  ">
    <div class="father ">
    <div class="login ">
      <div class="title">
        <h1>Login</h1>
      
      </div>
      
      <form class="formulario" action="#" @submit="login" >
        
        <div class="form-group">
          <input
            type="email"
            class="form-control formulario__input"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            v-model="email"
            
            @click="forms"
          />
          <label for="exampleInputEmail1" class="formulario__label">
            <font-awesome-icon icon="user" />Email
          </label>
        </div>
        <div class="form-group">
          <input
            type="password"
            class="form-control formulario__input"
            id="exampleInputPassword1"
            v-model="password"
            @click="forms"
          />
          <label for="exampleInputPassword1" class="formulario__label">
            <font-awesome-icon icon="key" />Password
          </label>
        </div>

        <button type="submit" class="btn btn-lg btn-block button ">LOGIN</button>

        
      </form>
      </div>
    </div>
    <MenuBottom />
  </div>
</template>
<script>
import MenuBottom from '@/components/MenuBottom.vue'
import auth from '@/firebase/init.js'
import firebase from "firebase";

import router from '../router'

export default {
  name: 'AddBoard',
  components:{
    MenuBottom
  },

  data() {
    return {
     log: { nickname: '' },
      email: "",
      password: "",
      trigger: ""
    };
  },
  methods: {
    login(evt) {
      this.trigger = "";
      if (this.email && this.password) {
        firebase
          .auth()
          .signInWithEmailAndPassword(this.email, this.password)
          .then(user => {
            alert("Inicio de sesion Correctamente :D");
            this.$router.push({ name: "dashboard" });
          })
          .catch(err => {
            alert('error al iniciar sesion, verifique su contraseña o correo.');
            this.error = err.message;
          });
      } else {
        this.trigger = "Todos los campos son requeridos";
      }
      evt.preventDefault()

      router.push({
        name: 'RoomList',
        params: { nickname:this.log.nickname }
      })
      
    },

    

    forms() {
      var input = document.getElementsByClassName("formulario__input");
      for (var i = 0; i < input.length; i++) {
        input[i].addEventListener("keyup", function() {
          if (this.value.length >= 1) {
            this.nextElementSibling.classList.add("fijar");
          } else {
            this.nextElementSibling.classList.remove("fijar");
          }
        });
      }
    }
  }
};
</script>

<style lang="scss" scoped>
@import '@/scss/coolors.scss';
.father{
background-image: url("../assets/backlogin2.jpg");
height: 100vh;
display: flex;
justify-content: center;
align-items: center;
}
.button{
color:white;
background: rgba(25,125,10,1);
background: -moz-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: -webkit-gradient(left top, left bottom, color-stop(0%, rgba(25,125,10,1)), color-stop(51%, rgba(73,158,58,1)), color-stop(60%, rgba(67,168,57,1)), color-stop(71%, rgba(61,184,65,1)), color-stop(100%, rgba(96,201,91,1)));
background: -webkit-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: -o-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: -ms-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: linear-gradient(to bottom, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#197d0a', endColorstr='#60c95b', GradientType=0 );
}

.FormLogin {
  .login {
    border: 2px solid $sombra;
    border-radius: 20px;
    background: -webkit-gradient(left top, right bottom, color-stop(0%, rgba(0,0,0,1)), color-stop(47%, rgba(65,82,65,0.75)), color-stop(75%, rgba(159,191,167,0.6)), color-stop(100%, rgba(159,191,167,0.47)));
background: -webkit-linear-gradient(-45deg, rgba(0,0,0,1) 0%, rgba(65,82,65,0.75) 47%, rgba(159,191,167,0.6) 75%, rgba(159,191,167,0.47) 100%);
background: -o-linear-gradient(-45deg, rgba(0,0,0,1) 0%, rgba(65,82,65,0.75) 47%, rgba(159,191,167,0.6) 75%, rgba(159,191,167,0.47) 100%);
background: -ms-linear-gradient(-45deg, rgba(0,0,0,1) 0%, rgba(65,82,65,0.75) 47%, rgba(159,191,167,0.6) 75%, rgba(159,191,167,0.47) 100%);
background: linear-gradient(135deg, rgba(0,0,0,1) 0%, rgba(65,82,65,0.75) 47%, rgba(159,191,167,0.6) 75%, rgba(159,191,167,0.47) 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#000000', endColorstr='#9fbfa7', GradientType=1 );
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    .title {
      h1 {
        color: white;
        margin-bottom: 1vh;
      }
    }
    .formulario {
      padding: 6%;
        .formulario__label {
        color: $sombra;
        font-size: 20px;
        margin-top: -80px;
        z-index: 2;
        padding-left: 15px;
        position: absolute;
        transition: 0.2s;
      }
      .formulario__input {
        font-size: 20px;
        padding: 20px;
        margin-bottom: 40px;
      }
      .formulario__input:focus + .formulario__label {
        margin-top: -120px;
        color: rgb(255, 255, 255);
      }
      .formulario__button:hover {
        background-color: $formBtn;
        transition: all 500ms ease;
      }
      .fijar {
        margin-top: -120px;
        color: $negro;
      }
      .google {
        border-radius: 50px;
      }
    }
  }
}
@media  (min-width: 481px) and (max-width: 900px) and (orientation: landscape){
h1{
  display:none;
 
}
.title{
  
  background-color:green;
}
 .login {
   width: 80vw;
   height: 90vh;
    border: 2px solid $sombra;
    border-radius: 20px;
    background-color: $blanco;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
  .formulario {
      padding: 6%;
        .formulario__label {
        color: $sombra;
    
        font-size: 2vw !important;
        margin-top: -10vw !important;
        z-index: 2;
        padding-left: 15px;
        position: absolute;
        transition: 0.2s;
      }
      .formulario__input {
        font-size: 20px;
        padding: 20px;
        margin-bottom: 5vw !important;
      }
      .formulario__input:focus + .formulario__label {
        margin-top: -15vw !important;
        color: rgb(255, 255, 255) !important; 
      }
      .formulario__button:hover {
        background-color: $formBtn;
        transition: all 500ms ease;
      }
      .fijar {
        
        color: $negro;
      }
      .google {
        width: 50vw;
        height: 6vw;
        font-size:4vh;
        border-radius: 50px;
        padding: 0;
      }
      .button{
        padding: 0;
        width: 50vw;
        height: 6vw;
      }
    }


  

}



</style>