<template>
  <div class="matchesresponsive">
      <headerPage />
      <mw></mw>
    <MenuBottom />
  </div>
</template>
<script>
import headerPage from '@/components/headerPage.vue'
import MenuBottom from '@/components/MenuBottom.vue'
import mw from '@/components/MatchWeek.vue'
export default {
    name:'matches',
  components: {
    headerPage,
    mw,
    MenuBottom
  }
}
</script>
<style lang="scss" scoped>
  .fechas {
  border-style: solid 2px black;
  margin: 20px;
}
.partido {
  margin: 20px;
  width: 100wh;
}
</style>