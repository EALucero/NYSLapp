<template>
  <div class="new5">
    <img alt="cesto" src="../assets/alaB.jpg">
    <main class="container">
      <h2>El Globo levantó vuelo</h2>
        <h4>Huracán fue infalible contra Banfield. El equipo de Damonte goleó 3-0 al Taladro y sumó su segundo triunfo consecutivo. En el equipo de Falcioni hubo clima caliente entre los hinchas y la comisión.</h4>
          <p>Israel Damonte agarró un equipo, en su primera experiencia como entrenador, que venía en caída libre desde la polémica salida de Gustavo Alfaro y que encima no estaba autorizado a incorporar. Ese fue el contexto en esta recta final de la Superliga que tuvo que atravesar Huracán, con Copa Sudamericana de por medio (eliminado en primera fase vs. Atlético Nacional).</p>
          <p>Desde el primer momento se vio la idea de juego del DT, aunque, por flojos resultados y cierta mala suerte, el foco estuvo desviado. Le costó arrancar aunque lo hizo, tarde (o no) pero seguro. El Globo aplastó al Banfield de Julio César Falcioni a domicilio por 3-0 con goles de Nicolás Cordero, Martín Ojeda (dos apuestas plenas del míster) y de Andrés Chávez, quien en la primera que tocó catapultó la inexorable ley del ex. Pese a que tardó varios encuentros en conseguir una victoria, Damonte puede respirar tranquilo: se viene la Copa Superliga que, con este envión, le puede permitir seguir sumando para no estar tan pendientes en el tema del descenso. Cosa contraria al Taladro del Emperador, que se retiró bajo una catarata de silbidos por parte de su público (e insultos a la comisión directiva).</p>
          <p>En la primera parte no pasaba nada, absolutamente nada. Era un encuentro chato y sin chances de gol, hasta que, en una corajeada personal, Briasco tiró un centro certero que Ojeda agarró de volea y transformó en un verdadero golazo. Así se terminaron los primeros 45 minutos.</p> 
          <p>En el complemento, Falcioni mandó de entrada a Jesús Dátolo, en búsqueda de adelantar a su equipo e ir por la igualdad, pero nada cambió: Cordero convirtió de tiro libre y sepultó las chances del local de quedarse con algo. Para colmo, como si fuera poco, el Comandante Chávez convirtió el tercero, lo que culminó con la poca paciencia que le quedaba a la hinchada local.</p>
          <p>Así se terminó el torneo para ambos: el Globo no para de volar y llega óptimo a la Copa. Mientras que Banfield vive cuesta arriba y sufre con la zona roja...</p>         
    </main>
  </div>    
</template>
