<template>
  <div class="new6">
    <img alt="ñuls" src="../assets/frio.jpg">
    <main class="container">
      <h2>Insólito: se le cayó el escudo de la camiseta</h2>
        <h4>Mariano Bíttolo, defensor de Newell's, protagonizó una curiosa escena en el Cilindro de Avellaneda al perder la insignia de su casaca. Las estrellas, igual, se quedaron en su lugar.</h4>
          <p>Es común ver camisetas en pleno partido que se rompen por algún agarrón. Pero lo que le sucedió a Mariano Bíttolo, defensor de Newell's, en el encuentro contra Racing es muy curioso: se le cayó el escudo de la camiseta. Sí, insólito...</p>
          <p>La trasmisión oficial captó a los 44 minutos del segundo tiempo la llamativa imagen, en donde se pudo observar de cerca al formado en Vélez Sarsfield de cerca. Vale señalar que zurdo salió al campo de juego con la pilcha intacta, pero todo hace parece que en algún forcejeo perdió la insignia. Ojo, las estrellas de La Lepra ni se movieron.</p>
    </main>
  </div>    
</template>
