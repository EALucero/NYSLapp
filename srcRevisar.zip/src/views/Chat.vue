<template>
  <div>
      <headerPage />
      
    <MenuBottom />
  </div>
</template>
<script>
import headerPage from '@/components/headerPage.vue'
import MenuBottom from '@/components/MenuBottom.vue'
export default {
    name:'chat',
  components: {
    headerPage,
    MenuBottom
  }
}
</script>
<style lang="scss" scoped>
  
</style>