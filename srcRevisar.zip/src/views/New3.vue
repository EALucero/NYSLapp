<template>
  <div class="new3">
    <img alt="silbido" src="../assets/amargo.jpg">
    <main class="container">
      <h2>Revivió el Rojo</h2>
        <h4>Con goles de Roa, Nani en contra y Romero, Independiente venció 3-0 a Central Córdoba y cortó una racha de cuatro partidos sin triunfos.</h4>
          <p>Los minutos corrían y la impaciencia de los hinchas crecía a pesar de que Independiente ​era el protagonista del partido, el que buscó, el que mereció ganar, el que pegó un tiro en el travesaño después de una linda jugada colectiva, el que no se rindió y consiguió el tan anhelado triunfo... Sí, el Rojo revivió: venció 3-0 a Central Córdoba de Santiago del Estero cortó una racha de cuatro fechas sin victorias.</p>
          <p>Fueron prácticamente 90 minutos en los que el Rojo fue con decisión por los tres puntos. En su casa, con su público, contra un rival que buscaba oxígeno en su pelea por no descender, no eludió el rol que debía tener de salir a buscar. Con un equipo renovado de sangre joven, los pibes le dieron vitalidad al juego. "Vamos vamos los pibes", fue el grito final que bajó de las tribunas. Y bien merecido lo tienen...</p>
          <p>Con los santiagueños entregando la pelota y el terreno, Independiente inclinó la cancha y de a poco le fue metiendo cada vez más peligro al arco del Ruso Rodríguez. Se le negó varias veces en el primer tiempo (Silvio Romero desperdició dos chances) y en la segunda parte también le dijo que no el travesaño a ese remate del Chacho Martínez.</p> 
          <p>Hasta que el colombiano Roa se metió en el área por derecha, con enganche de por medio, y sacó un zurdazo al segundo palo que abrió el arco. Detrás llegaron los tantos de Nani en su propio arco y el desahogo de Romero. Un desahogo que sintieron todos: los jugadores, Pusineri y la gente...</p>
    </main>
  </div>    
</template>
