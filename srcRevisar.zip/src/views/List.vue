<template>
  <div>
    <headerPage />
    <div class="list">
    
    <h2 class="text-center">List of teams</h2>
    <main class="container">
      <section>
        <div class="box" v-for="(team,index) in teams" :key="index">
          <div >
            <img alt="bokita" :src="require('@/assets/shields/' + team.logo)" height="75">
          </div>
          <div >
            <h3>{{team.name}}</h3>
            <p>{{team.nickname}}</p>
          </div>
        </div>
        <div class="box" v-for="(team,index) in teams" :key="index">
          <div>
            <img alt="cesto" src="../assets/shields/huracan.png">
          </div>
          <div>
            <h3>{{team.name}}</h3>
            <p>{{team.nickname}}</p>
          </div>
        </div>
        <div class="box" v-for="(team,index) in teams" :key="index">
          <div>
            <img alt="oxido" src="../assets/shields/independiente.png">
          </div>
          <div>
            <h3>{{team.name}}</h3>
            <p>{{team.nickname}}</p>
          </div>
        </div>
        <div class="box" v-for="(team,index) in teams" :key="index">
          <div>
            <img alt="nadie" src="../assets/shields/newells.png">
          </div>
          <div>
            <h3>{{team.name}}</h3>
            <p>{{team.nickname}}</p>
          </div>
        </div>
        <div class="box" v-for="(team,index) in teams" :key="index">
          <div>
            <img alt="dinos" src="../assets/shields/racing.png">
          </div>
          <div>
            <h3>{{team.name}}</h3>
            <p>{{team.nickname}}</p>
          </div>
        </div>
        <div class="box" v-for="(team,index) in teams" :key="index">
          <div>
            <img alt="pechos" src="../assets/shields/river.png">
          </div>
          <div>
            <h3>{{team.name}}</h3>
            <p>{{team.nickname}}</p>
          </div>
        </div>
        <div class="box" v-for="(team,index) in teams" :key="index">
          <div>
            <img alt="gateros" src="../assets/shields/central.png">
          </div>
          <div>
            <h3>{{team.name}}</h3>
            <p>{{team.nickname}}</p>
          </div>
        </div>
        <div class="box" v-for="(team,index) in teams" :key="index">
          <div>
            <img alt="super" src="../assets/shields/sanlorenzo.png">
          </div>
          <div>
            <h3>{{team.name}}</h3>
            <p>{{team.nickname}}</p>
          </div>
        </div>
       
        
      </section>
    </main>
    
  </div>  

    <MenuBottom />
  </div>
</template>
<script>
import headerPage from "@/components/headerPage.vue";
import MenuBottom from "@/components/MenuBottom.vue";
import { db } from "@/firebase/init.js";
export default {
  name: "teams",
  components: {
    headerPage,
    MenuBottom
  },
  data() {
    return {
      teams: []
    };
  },
  created() {
    db.ref("teams")
      .once("value")
      .then(snap => {
        this.teams = snap.val();
      });
  }
};
</script>
<style lang="scss" scoped>
.list {
    background:#347740;
    color:beige;
  }
  section{
    background: url("../assets/paste.jpg");
    margin: 2%;
    padding: 2%;
    border-radius: 25px;
    margin-bottom: 11vh;
  }
  .box{
    display: flex;
    justify-content: space-around; 
    height: 16vh;
    margin: 2%;
    background: rgba(0, 0, 0, 0.600);
    border-radius: 20px;
  }
  img{
    height: 14vh;
    position: relative;
    bottom: 8px;
    margin: 12px;
  }
  h3{
    font-size: 16px;
    margin: 10px;
    text-align: left;
  }
   p{
    font-size: 12px;
    margin: 10px;
    text-align: left;
  }
</style>

