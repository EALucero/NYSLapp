<template>
  <div class="new2">
    <img alt="adentro" src="../assets/mapache.jpg">
    <main class="container">
      <h2>Lo ganó Boca y lo perdió River</h2>
        <h4>La reinvención de uno y el bache del otro. Más allá de las polémicas en el último partido, River mostró dificultades en el cierre de la Superliga mientras que Boca tuvo un 2020 implacable.</h4>
          <p>Una vez que la fiesta de uno y la calentura del otro se equilibran un poco más, en la evaluación del campeón no se puede dejar poner los méritos que hizo Boca y los que le faltaron a River a la hora de ver por qué se dio la vuelta olímpica en la Bombonera. Independientemente del análisis de los penales que no se dieron, del offside mal cobrado, el renovado Tevez, los cambios que metió Russo, la renovación espiritual de un equipo hizo que metiera seis triunfos y un empate de siete en 2020, como para justificar largamente el título de campeón.</p>
          <p>Gallardo, con esa capacidad para analizar que cada día lo hace mejor entrenador, tampoco eligió como foco principal poner la bronca por el desempeño arbitral por encima de lo que no pudieron sostener como mejor equipo en estos últimos años que mostró ser su River. Incluso, su lenguaje corporal post empate -gusto a derrota- tras el primer mazazo de este año que fue el empate en el Monumental contra Defensa y Justicia y la decisión de ni completar el banco en la Libertadores, parecieron exponer que el Muñeco veía que no era el mejor momento de su equipo y hasta se ligó una anginas de aquellas que lo tumbaron.</p>
          <p>En menos de tres meses, Ameal, Román, Russo, Tevez​, o todos juntos, lograron levantar un Boca que venía de un nuevo nocaut copero luego del peor nocaut de su historia en Madrid. Y aunque en esta definición de la Superliga no había clásico para jugar y resolver la historia, ambos se alimentaron de la competencia del otro para elevar el torneo a un standard mayor al que habían tenido los anteriores.</p> 
          <p>La aparición de este Tevez recargado 2020 resultó ser el antídoto para que Boca pudiera frenar, o al menos interrumpir por un rato, esos equipos de Gallardo que parecían destinados a ganarle hasta jugando a las bochas. Lo ganó Boca porque se reinventó rápido, tuvo carácter para pelear siempre, paciencia, mejoró y sumó como pocas veces. Lo perdió River porque hasta los grandes equipos tienen sus baches.</p>
    </main>
  </div>    
</template>
