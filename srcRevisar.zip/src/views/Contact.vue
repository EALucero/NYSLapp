<template>
  <div>
    <headerPage />
    <formContact />
    <MenuBottom />
  </div>
</template>
<script>
import formContact from "@/components/formContact.vue";
import headerPage from "@/components/headerPage.vue";
import MenuBottom from "@/components/MenuBottom.vue";
export default {
  name: "contact",
  components: {
    formContact,
    headerPage,
    MenuBottom
  }
};
</script>