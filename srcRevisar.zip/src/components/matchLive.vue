<template>
  <div id="back" class="container mb-5">
    <div class="d-flex justify-content-center">
      <div id="inlive" class="mb-2">
        <h2>
          Matchs
          <i>
            <img id="redpoint" src="@/assets/redpoint.png" alt="red point" />
          </i>
        </h2>
      </div>
    </div>
    <div class="container" v-for="match in filterMatches" :key="match.id">
      <div class="father">
      <div class="row d-flex">
          <div class="col align-self-center d-flex flex-column flex-nowrap">
            <img class="images align-self-center" :src="require('@/assets/shields/'+ getLogo(match.equipoLocal))" :alt="getLogo(match.equipoLocal)" />
            <p class="align-self-center">{{match.equipoLocal}}</p>
          </div>
          <div class="col d-flex flex-column flex-wrap">
            <p class="align-self-center">{{match.date}}</p>
            <img class="vs align-self-center" src="@/assets/vs.png" alt="VS" />
            <p class="align-self-center">{{match.horario}}</p>
          </div>
          <div class="col d-flex flex-column flex-wrap">
            <img class="images align-self-center" :src="require('@/assets/shields/'+getLogo(match.equipoVisital))" :alt="getLogo(match.equipoVisital)" />
            <p class="align-self-center">{{match.equipoVisital}}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { db } from "@/firebase/init.js";
export default {
  name: "matchs",
  data() {
    return {
      date: "",
      teams: [],
      matches:[],
      currentMatchWeek:0
    };
  },
  created() {
    this.saveTeams(
      db
        .ref("teams")
        .once("value")
        .then(snap => {
          this.teams = snap.val();
        })
    ),
      this.saveMatches(
        db
          .ref("matches")
          .once("value")
          .then(snap => {
            this.matches = snap.val();
            this.date = this.getDay()
            this.currentMatchWeek = this.getMatchWeek()
             })
      );
  },
  methods: {
    ...mapMutations(["saveMatches"]),
    ...mapMutations(["saveTeams"]),
    getDay() {
      var today = new Date();
      var dates =
        today.getFullYear() +
        "-" +
        (today.getMonth() + 1) +
        "-" +
        today.getDate();
      return dates;
    },
    getLogo(name) {
      var logo = "";
      this.teams.forEach(e => {
        if (e.name === name) {
          logo = e.logo;
        }
      });
      return logo;
    },
    getMatchWeek(){
      let aux= 99
      this.matches.forEach(e => {
        if(e.date >= this.date && e.fecha < aux){
          aux = e.fecha
        }
      });
      return aux
    }
  },
  computed:{
    filterMatches() {
      return this.matches.filter(e => e.fecha === this.currentMatchWeek).sort(function(a,b){
        return a.horario - b.horario;
      });
    }
  }
};
</script>
<style scoped>
p{
  color:white
}
.images {
  width: 9vh;
}
.row {
  margin-bottom: 6vh;
  background-color: rgba(0, 0, 0, 0.589);
  border: rgb(38, 255, 0) solid 0.2vh;
}
.vs {
  width: 10vw;
}
#redpoint {
  width: 2vh;
  align-items: center;
  animation-name: redpoint;
  animation-duration: 1.5s;
  animation-iteration-count: infinite;
}
#back {
  -webkit-box-shadow: -4px 46px 57px -3px rgba(0, 0, 0, 0.52);
  -moz-box-shadow: -4px 46px 57px -3px rgba(0, 0, 0, 0.52);
  box-shadow: -4px 46px 57px -3px rgba(0, 0, 0, 0.52);
  border-top-left-radius: 100px;
  border-top-right-radius: 100px;
  background-image: url("../assets/paste.jpg");
  margin-top: 3%;
  border-bottom: rgb(38, 255, 0) solid 0.2vh;
}
h2 {
  text-align: center;
  font-size: 16px;
  color: rgb(255, 255, 255);
}
#inlive {
  border: 0.2vh solid rgb(38, 255, 0);
  background-color: rgba(0, 0, 0, 0.698);
  border-radius: 4vh;
  height: 4.2vh;
  width: 25vw;
}
/* RESPONSIVE */
@media (min-width: 300px) and (orientation: landscape){
  #inlive{
   height: 4.3vw;
  }
}
@media (min-width: 300px) {
  #back {
    border-radius: 0;
  }
  #inlive {
    width: 100px;
  }
  h2 {
    font-size: 17px;
  }
}
@media (min-width: 425px) {
  .tamaño {
    height: 40vh;
    width: 80vw;
  }
  #inlive {
    width: 100px;
  }
  #back {
    border-radius: 0;
  }
  h2 {
    font-size: 18px;
  }
  .row {
    width: 425px;
    border-radius: 25px;
  }
  .father {
    display: flex;
    justify-content: center;
  }
}
@media (min-width: 540px) and (orientation: landscape) {
  .images {
    height: 80px;
    width: 80px;
  }
  .row {
    width: 900px;
    height: 120px;
    border-radius: 25px;
  }
  #back {
    border-top-left-radius: 10vh;
    border-top-right-radius: 10vh;
  }
}
@media (min-width: 736px) and (orientation: landscape) {
  #inlive {
    width: 100px;
    height: 30px;
  }
  h2 {
    font-size: 22px;
  }
  .row {
    width: 900px;
    height: 120px;
    border-radius: 25px;
  }
  .images {
    height: 90px;
    width: 90px;
  }
  .vs {
    width: 60px;
  }
  .father {
    display: flex;
    justify-content: center;
  }
}
@media (min-width: 800px) {
  #redpoint {
    width: 13px;
  }
  #inlive {
    width: 120px;
    height: 30px;
  }
  h2 {
    font-size: 22px;
  }
  .row {
    align-items: center;
    width: 900px;
    height: 150px;
    border-radius: 25px;
  }
  .images {
    height: 100px;
    width: 100px;
  }
  .vs {
    width: 70px;
  }
  .father {
    display: flex;
    justify-content: center;
  }
}
@media (min-width: 1440px) {
  #inlive {
    width: 100px;
    height: 70px;
  }
}
/* animation */
@keyframes redpoint {
  0% {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(150deg);
  }
  100% {
    transform: rotate(150deg);
  }
}
</style>