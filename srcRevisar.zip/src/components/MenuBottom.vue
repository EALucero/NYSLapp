<template>
  <div class="none">
    <div class="menu">
      <div class="navbarBottom">
        <template v-if="user">
          <div class="nav-item">
            <router-link to="/dashboard">
              <font-awesome-icon icon="home" class="text-light" />
            </router-link>
          </div>
          <div class="nav-item">
            <router-link to="/matches">
              <font-awesome-icon icon="futbol" class="text-light" />
            </router-link>
          </div>
          <!--
          <div class="nav-item">
            <router-link to="/chat">
              <font-awesome-icon icon="comment" class="text-light" />
            </router-link>
          </div>-->
          <div class="nav-item">
            <a @click.prevent="logout">
              <font-awesome-icon icon="sign-out-alt" class="text-light" />
            </a>
          </div>
        </template>
        <template v-else>
          <div class="nav-item">
            <router-link to="/register">
              <font-awesome-icon icon="user-plus" class="text-light" />
            </router-link>
          </div>
          <div class="nav-item">
            <router-link to="/">
              <font-awesome-icon icon="user-plus" class="text-light" />
            </router-link>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>
<script>
import "bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import firebase from "firebase";
export default {
  name: "MenuBottom",
  data() {
    return {
      user: null
    };
  },
  methods: {
    logout() {
      firebase
        .auth()
        .signOut()
        .then(() => {
          this.$router.push({ name: "login" });
        });
    }
  },
  created() {
    firebase.auth().onAuthStateChanged(user => {
      if (user) {
        this.user = user;
      } else {
        this.user = null;
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.none {
  width: 100vw;

  .menu {
    height: 12vh;
    width: 100vw;
    position: fixed;
    bottom: 0;
    background: rgba(25,125,10,1);
background: -moz-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: -webkit-gradient(left top, left bottom, color-stop(0%, rgba(25,125,10,1)), color-stop(51%, rgba(73,158,58,1)), color-stop(60%, rgba(67,168,57,1)), color-stop(71%, rgba(61,184,65,1)), color-stop(100%, rgba(96,201,91,1)));
background: -webkit-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: -o-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: -ms-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: linear-gradient(to bottom, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#197d0a', endColorstr='#60c95b', GradientType=0 );
    display: flex;
    flex-direction: column;
    justify-content: center;
    .navbarBottom {
      display: flex;
      flex-direction: row;
      justify-content: space-around;
      align-items: center;

      .nav-item {
        height: 12vh;
        width: 100vw;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        font-size: 30px;
        a {
          color: white;
          text-decoration: none;
          
        }
        &:hover {
          background-color: #89d573;
          transition: all 0.2s;
          cursor: pointer;
        }
      }
    }
  }
}
</style>