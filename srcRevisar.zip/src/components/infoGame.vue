<template>
  <div>
    <div class="container_father d-flex justify-content-center">
      <div class="container boxes">
        <div class="row">
          <div class="flip-card d-flex justify-content-center col-12 col-md-6 col-lg-4 box">
            <div class="flip-card-inner card">
              <div class="flip-card-front">
                <img src="@/assets/mission.png" alt="no funk la bocha" />
              </div>
              <div class="flip-card-back card-body cards">
                <h3 class="card-title">Mission</h3>
                <p
                  class="card-text text-left"
                >To support young athletes living in Chicago´s northside neighborhoobs, who have an interest in learning and playing soccer,with opportunities to learn and practice skills related to the game of soccer, specifically those skills around team cooperation and good sportsmanship.</p>
              </div>
            </div>
          </div>
          <div class="flip-card d-flex justify-content-center col-12 col-md-6 col-lg-4 box">
            <div class="flip-card-inner card">
              <div class="flip-card-front">
                <img src="@/assets/vision.jpg" alt="no funk la bocha" />
              </div>
              <div class="flip-card-back card-body cards">
                <h3 class="card-title">Vision</h3>
                <p
                  class="card-text text-left"
                >The Northside Youth Soccer League aspires to develop strong, well-rounded, and mindful athletes through the building of character, self-discipline, and leadership.</p>
              </div>
            </div>
          </div>
          <div class="flip-card d-flex justify-content-center col-12 col-md-6 col-lg-4 box">
            <div class="flip-card-inner card">
              <div class="flip-card-front">
                <img src="@/assets/info.png" alt="no funk la bocha" />
              </div>
              <div class="flip-card-back card-body cards">
                <h3 class="card-title">General Information</h3>
                <p
                  class="card-text text-left"
                >The Northside Youth Soccer League was estabilished in 1996 to provide athletes residing in Chicago´s notthside neighborhoods an environment in which to learn and play soccer. To be a member of NYSL, you must be between the ages of 4 - 12 and reside in a Chicago northside neighborhood. NYSL is ran by a small full-time staff, and relies on the generous vulunteer time of parents and previous league members.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import "bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
export default {
  name: "infogame"
};
</script>



<style scoped>
.cards{
  overflow: scroll;
}
/* Flip */
.flip-card {
  background-color: transparent;
  width: 300px;
  height: 200px;
  perspective: 1000px; /* Remove this if you don't want the 3D effect */
  outline: none;
}
/* This container is needed to position the front and back side */
.flip-card-inner {
  position: relative;
  width: 50vw;
  height: 100%;
  text-align: center;
  transition: transform 0.8s;
  transform-style: preserve-3d;
}
/* Do an horizontal flip when you move the mouse over the flip box container */
.flip-card:hover .flip-card-inner {
  transform: rotateY(180deg);
}
/* Position the front and back side */
.flip-card-front,
.flip-card-back {
  position: absolute;
  width: 50vw;
  height: 190px;
  -webkit-backface-visibility: hidden; /* Safari */
  backface-visibility: hidden;
}
/* Style the front side (fallback if image is missing) */
.flip-card-front {
  background-color:white;
  color: black;
}
/* Style the back side */
.flip-card-back {
background: rgb(10,64,2);
  background: linear-gradient(0deg, rgba(10,64,2,0.720792540649072) 0%, rgba(32,154,22,0.8412407199207808) 48%, rgba(52,200,28,1) 100%);
  color: white;
  transform: rotateY(180deg);
}
/* Flip */
img {
  width: 200px;
  height: 190px;
}
.container_father {
  align-items: center;
  width: 100%;
  min-height: 100vh;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  padding: 3px, 5px, 3px, 5px;
  background: #4b894b;
}
.boxes {
  margin-top: 20px;
  margin-bottom: 15vh;
}
/* Resposive */
@media (min-width: 0px) and (orientation: landscape) {
.boxes {
  margin-top: 20px;
}
.box{
  width: 5vw;
}
}
</style>