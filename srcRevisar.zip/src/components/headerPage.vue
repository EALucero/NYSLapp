<template>
  <div class="about ">
    <header class="navbar navbar-expand-lg navbar-dark toggled" id="wrapper">
      <!--Dropdown  que contiene el menu que se desliza de costado -->
        <img  src="@/assets/logo.png" style="background-size: cover;background-repeat: no-repeat;background-position:center;" height="80" width="80" alt />

      <div class="dropdown">
        <button class="btn btn-success dropbtn menu-toggle">
          <font-awesome-icon icon="align-left" />
        </button>
        <div id="sidebar-wrapper" class="abouts">
          <div class="sidebar-header">
            <img
              src="@/assets/logo.png"
              class="logoside"
              style="background-color:#347740;padding:10px;border-top-left-radius: 50%;border-top-right-radius: 50%;"
              height="100"
              width="100"
              alt
            />
            <button class="button-menu btn btn-success dropbtn menu-toggle">
              <font-awesome-icon icon="times" />
            </button>
          </div>
          <div class="sidebar-content">
            <router-link class="menu-side text-center" to="/teams">Teams</router-link>
            <router-link class="menu-side text-center" to="/about">About</router-link>
            <router-link class="menu-side text-center" to="/contact">Contact</router-link>
          </div>
          <div class="sidebar-social text-light">
            <div class="icon-social">
              <img src="@/assets/twitter.png" height="50" alt="">
            </div>
            <div class="icon-social">
              <img src="@/assets/fb.png" height="50" alt="">
            </div>
            <div class="icon-social">
              <img src="@/assets/ig.png" height="50" alt="">
            </div>
          </div>
        </div>
      </div>
    </header>

    
  </div>
</template>
<script>

import $ from "jquery";

export default {
  name: "headerPage",
  

  mounted() {
    $(document).ready(function() {
      $(".menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
      });
    });
  }
};
</script>
<style lang="scss" scoped>
.abouts{

  display: flex;
  position: fixed;
  z-index: 99;
}
.navbar {
  -webkit-box-shadow: 2px 4px 32px -13px rgba(0, 0, 0, 0.75);
  -moz-box-shadow: 2px 4px 32px -13px rgba(0, 0, 0, 0.75);
  box-shadow: 2px 4px 32px -13px rgba(0, 0, 0, 0.75);
  background-image: url("../assets/banner3.jpg");
  height: 17vh;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  
  
}
.color {
  background-color: #0c4600;
  z-index: 3;
}
.user {
  background-color: white;
  border: 2px solid black;
  text-align: center;
  border-radius: 50%;
  height: 50px;
  width: 50px;
  display: flex;
  flex-direction: row;
  justify-content: center;
}
.menu {
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  margin: 20px;
  text-align: center;
  border: 5px solid black;
  border-radius: 70%;
  height: 150px;
  width: 150px;
  
}
.nav-item {
  font-size: 23px;
  padding: 10px;
}
.nav-item:hover {
  border-bottom: 3px solid #5fde47;
  transition: all 0.2s;
}
.arrow {
  position: absolute;
  left: 1vw;
  top: 1vh;
}
.arrow:hover {
  background-color: rgba(0, 0, 0, 0.5);
  transition: all 0.5s;
}
.user:hover,
.menu:hover {
  background-color: rgba(0, 0, 0, 0.3);
  transition: all 0.2s;
  color: white;
}
.router-link-active {
  border-bottom: 3px solid #5fde47;
  transition: all 0.2s;
}
.logo {
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
}
.dropdown {
  position: absolute;
  top: 2vw;
  left: 2vw;
  z-index: 999;
}
#sidebar-wrapper {
  min-height: 100vh;
  position: absolute;
  left: -3vw;
  top: -2vh;
  width: 80vw;
  transition: margin 0.25s;
  background-color: #333;
  display: none;
  .sidebar-header {
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: flex-end;
    background-color: #454644;
    border-bottom: 2px solid #71bf3d;
    -webkit-box-shadow: 2px 4px 32px -13px rgba(0, 0, 0, 0.75);
    -moz-box-shadow: 2px 4px 32px -13px rgba(0, 0, 0, 0.75);
    box-shadow: 2px 4px 32px -13px rgba(0, 0, 0, 0.75);
    height: 25.5vh;
    
    .button-menu {
      height: auto;
      position: absolute;
      right: 4vw;
      top: 5vh;
    }
  }
}
.sidebar-content {
  display: flex;
  flex-direction: column;
  height: 55vh;
  margin-top: 10vh;
  .menu-side {
    background-color: black;
    width: 75vw;
    color: white;
    margin:3vh 0 ;
    font-size: 25px;
    border: 2px solid #a3fb3e;
    border-top-right-radius: 20px;
    border-bottom-right-radius: 20px;
  }
}
.sidebar-social {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  .icon-social {
    height: 10vh;
    width: 15vw;
    
  }
}
.sidebar-content .sidebar-item {
  color: white;
  padding: 10px 10px;
}

@media (min-width: 200px) {
  #sidebar-wrapper {
    margin-left: 0;
    display: inline-block;
  }
  #page-content-wrapper {
    min-width: 0;
    width: 100%;
  }
  #wrapper.toggled #sidebar-wrapper {
    margin-left: -30rem;
  }
}
</style>
