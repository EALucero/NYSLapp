<template>
  <div class="matchWeek back mbot">
    <div>
      <label class="label"  v-for="fecha in getValueKey(matches, 'fecha')" :key="fecha.id">
        <input type="radio" :value="fecha" class="matches" v-model="currentMatch" />
        {{fecha}}
      </label>
      <div class="nextPrev">
        <button class="btn btn-success" @click="currentCalc(false)">
          <font-awesome-icon icon="arrow-left" />
        </button>
        <p class="nameMatch">MatchWeek {{currentMatch}}</p>
        <button class="btn btn-success" @click="currentCalc(true)">
          <font-awesome-icon icon="arrow-right" />
        </button>
      </div>
      <div class="back2">
        
      <p v-for="match in filterMatches" :key="match.id" class="matchs">
        <a @click="routeMatch(match.id)">
          <img :src="require('@/assets/shields/'+ getLogo(match.equipoLocal))"  class="mt-2 mb-2"  />
          {{match.equipoLocal}} VS {{match.equipoVisital}}
          <img
            :src="require('@/assets/shields/'+ getLogo(match.equipoVisital))" class="mt-2 mb-2"
            
          />
        </a>
      </p>
      
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { db } from "@/firebase/init.js";
export default {
  name: "MatchWeek",
  data() {
    return {
      matches: [],
      fechas: [],
      cantFechas: [],
      teams: [],
      currentMatch: 1
    };
  },
  created() {
    this.saveTeams(
      db
        .ref("teams")
        .once("value")
        .then(snap => {
          this.teams = snap.val();
        })
    ),
      this.saveMatches(
        db
          .ref("matches")
          .once("value")
          .then(snap => {
            this.matches = snap.val();
            this.matches.forEach(e => {
              if (this.cantFechas.includes(e.fecha) == false) {
                this.cantFechas.push(e.fecha);
              }
            });
            this.cantFechas.sort();
          })
      );
  },
  methods: {
    ...mapMutations(["saveMatches"]),
    ...mapMutations(["saveTeams"]),
    ...mapMutations(["getLogo"]),
    getValueKey(array, key) {
      let result = [];
      array.forEach(e =>
        !result.includes(e[key]) ? result.push(e[key]) : null
      );
      return result;
    },
    currentCalc(calc) {
      if (calc == true) {
        if (this.currentMatch > this.cantFechas.length - 1) {
          this.currentMatch = 1;
        } else {
          this.currentMatch++;
        }
      } else {
        if (this.currentMatch <= 1) {
          this.currentMatch = this.cantFechas.length;
        } else {
          this.currentMatch--;
        }
      }
    },
    routeMatch(id){
      this.$router.push({path: "match/"+id})
    },
    getLogo(name) {
      var logo = "";
      this.teams.forEach(e => {
        if (e.name === name) {
          logo = e.logo;
        }
      });
      return logo;
    }
  },
  computed: {
    changeCurrent() {
      return (this.currentMatch = this.fechas);
    },
    filterMatches() {
      return this.matches.filter(e => e.fecha === this.currentMatch);
    }
  }
};
</script>
<style scoped>
.matchs{
  display:flex;
  align-items: center;
  color: white;
  background-color: rgba(0, 0, 0, 0.596);
  border-top:solid 2px rgb(59, 211, 32);
  border-bottom:solid 2px rgb(59, 211, 32);
    
}
.label{
  background-color: rgba(0, 0, 0, 0.589);
  border: rgb(38, 255, 0) solid 0.2vh;
}
.back{
  height: 100vh;
background: rgba(25,125,10,1);
background: -moz-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: -webkit-gradient(left top, left bottom, color-stop(0%, rgba(25,125,10,1)), color-stop(51%, rgba(73,158,58,1)), color-stop(60%, rgba(67,168,57,1)), color-stop(71%, rgba(61,184,65,1)), color-stop(100%, rgba(96,201,91,1)));
background: -webkit-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: -o-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: -ms-linear-gradient(top, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
background: linear-gradient(to bottom, rgba(25,125,10,1) 0%, rgba(73,158,58,1) 51%, rgba(67,168,57,1) 60%, rgba(61,184,65,1) 71%, rgba(96,201,91,1) 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#197d0a', endColorstr='#60c95b', GradientType=0 );
}
img{
  width: 7vh;
}
.mbot{
  margin-bottom:6vw;
}
.back2{ 
  border-top-left-radius: 2vh;
  border-top-right-radius: 2vh;
  display:flex;
  flex-direction: column;
  justify-content: center;
  background-color: rgba(0, 0, 0, 0.589);
  border: rgb(38, 255, 0) solid 0.2vh;
  -webkit-box-shadow: -4px 46px 57px -3px rgba(0, 0, 0, 0.52);
  -moz-box-shadow: -4px 46px 57px -3px rgba(0, 0, 0, 0.52);
  box-shadow: -4px 46px 57px -3px rgba(0, 0, 0, 0.52);
  padding: 1vh 0;
  background-image: url("../assets/paste.jpg");
  margin-top: 3%;
  border-bottom: rgb(38, 255, 0) solid 0.2vh;
}
.matchWeek {
  display: flex;
justify-content: center;
}
.nextPrev {
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
}
.nameMatch {
  color:white;
    border-top-left-radius: 2vh;
  border-top-right-radius: 2vh;
  background-color: rgba(0, 0, 0, 0.657);
  padding: 15px;
  margin: 1vh;
  font-size: 18px;
}
.card-text {
  background-color: red;
}
input[type="radio"] {
  display: none;
}
label {
  padding: 3%;
  margin: 2%;
  background-color: green;
  color: white;
}
</style>