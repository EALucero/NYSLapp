<template>
  <div id="app">
    
    <router-view/>
  </div>
</template>
<script>
import "bootstrap"
import bootstrap from "bootstrap/dist/css/bootstrap.min.css"
export default {
  
}
</script>
<style lang="scss">

</style>
