import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    matches:'',
    teams:''
    
  },
  mutations: {
    saveMatches(state,database){
      state.matches = database
    },
    saveTeams(state,database){
      state.teams = database
    }
  },
  actions: {
  },
  modules: {
  }
})
